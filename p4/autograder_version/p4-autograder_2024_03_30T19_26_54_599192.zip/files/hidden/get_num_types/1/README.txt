function logic is incorrect

Check the implementation of `get_num_types` to
ensure it properly accounts for all Pokemon types,
including 'DNE'. Consider the function's logic and
make sure it returns the correct number of types
for each input it is given.