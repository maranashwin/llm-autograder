correct arguments are not passed to `friendship_score` function

Check that your `friendship_score` function is
defined correctly and accepts two parameters. Make
sure to pass the correct string arguments when
calling the function.