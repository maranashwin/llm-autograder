correct arguments are not passed to `type_bonus` function

Ensure the `type_bonus` function is called with
the correct string arguments for the Pokémon type
and name. Review the function parameters and the
expected arguments.