function output is incorrect when the `attacker` needs to choose its special attack

Confirm that your function chooses the correct
attack mode by comparing physical and special
damage. Ensure you have correctly used the
provided functions to compute damage values and
are comparing them accurately to return the
greater of the two. Review the calculation and
conditional statement logic.