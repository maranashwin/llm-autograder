correct arguments are not passed to `damage` function

The test checks if you passed the correct
arguments to the `damage` function. To fix your
code, ensure that the `damage` function must be
called with the exact Pokémon names: 'Tinkaton'
and 'Arcanine', in that order.