function output is incorrect when the `attacker` can do non-zero effective damage to the `defender`

Ensure your `num_hits` function correctly divides
HP by effective damage and rounds up. Use
`math.ceil`. Check for any logic errors that might
affect the outcome with various inputs.