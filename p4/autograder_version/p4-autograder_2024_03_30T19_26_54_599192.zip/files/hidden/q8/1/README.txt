correct arguments are not passed to `num_hits` function

The test ensures the `num_hits` function is called
with the correct arguments. Verify that the
arguments to `num_hits` match the order specified
in the function definition and that you are using
the correct Pokemon names as parameters.