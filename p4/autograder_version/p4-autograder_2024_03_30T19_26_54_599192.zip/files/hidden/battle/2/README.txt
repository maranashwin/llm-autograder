function output is incorrect when the two Pokemon can do damage to each other but take the same number of hits to defeat each other

The test checks for correct output when two
Pokemon can deal damage but take equal hits to
defeat each other. Verify your implementation of
`battle` and consider edge cases where the Pokemon
have the same number of hits to knock each other
out, ensuring your code accounts for speed as a
tiebreaker.