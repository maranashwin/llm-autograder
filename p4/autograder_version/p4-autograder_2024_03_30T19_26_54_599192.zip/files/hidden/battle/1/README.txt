function output is incorrect when the two Pokemon can do damage to each other and do not take the same number of hits to defeat each other

Ensure that your `battle` function correctly
compares the number of hits each Pokemon can take
using the `num_hits` function. Verify that you are
not calling the functions more times than needed,
which may change the logic. Check for correct
comparison logic for the number of hits and speed,
if applicable.