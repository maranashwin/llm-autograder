function output is incorrect when the `attacker` has two types

Ensure that your implementation of
`effective_damage` correctly handles cases where
the attacker has two types. Double-check your use
of `get_num_types` within the function. Consider
edge cases involving specific inputs not covered
by your local tests.