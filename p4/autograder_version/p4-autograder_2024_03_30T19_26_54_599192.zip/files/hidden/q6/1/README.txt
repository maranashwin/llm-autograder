correct arguments are not passed to `effective_damage` function

Check the arguments passed to `effective_damage`.
The function should be called with specific
parameters. Review the function's intended inputs.