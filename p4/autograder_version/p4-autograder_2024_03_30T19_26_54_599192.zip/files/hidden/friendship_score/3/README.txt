function logic is incorrect

Verify that your `friendship_score` function
correctly follows all the rules, especially when
the stat difference is not exactly 20 and when
both types do not match. Ensure proper checks for
'DNE' in `type2` and correct point allocation for
each rule.