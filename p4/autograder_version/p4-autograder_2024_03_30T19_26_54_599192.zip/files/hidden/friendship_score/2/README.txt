function output is incorrect when the two Pokemon have the same types but not necessarily the same corresponding types

Ensure your code strictly checks for corresponding
`type1` with `type1` and `type2` with `type2`.
Misaligned type comparisons or ignoring the `DNE`
case for `type2` can affect the result. Validate
comparisons for both type order and equality.