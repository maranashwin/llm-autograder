function output is incorrect when the stat difference of the two Pokemon is exactly 20

Ensure the comparison for stat difference accounts
for a maximum difference of 20 inclusively. Review
conditional checks and the usage of `abs()` in
your implementation.