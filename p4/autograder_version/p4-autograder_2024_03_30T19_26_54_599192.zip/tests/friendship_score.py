OK_FORMAT = True

test = {   'name': 'friendship_score',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('friendship_score: function output is incorrect when the stat difference of the two Pokemon is exactly 20')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the stat difference of the two Pokemon is exactly 20 (-1)'.The public tests cannot determine if your code satisfies these requirements. "
                                                          'Verify your code manually.'},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('friendship_score: function output is incorrect when the two Pokemon have the same types but not necessarily the same "
                                               "corresponding types')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the two Pokemon have the same types but not necessarily the same corresponding types (-1)'.The public tests cannot determine if your code "
                                                          'satisfies these requirements. Verify your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('friendship_score: function logic is incorrect')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
