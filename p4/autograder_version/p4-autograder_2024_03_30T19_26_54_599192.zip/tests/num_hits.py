OK_FORMAT = True

test = {   'name': 'num_hits',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('num_hits: function output is incorrect when the `attacker` can do non-zero effective damage to the `defender`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `attacker` can do non-zero effective damage to the `defender` (-2)'.The public tests cannot determine if your code satisfies these "
                                                          'requirements. Verify your code manually.'},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('num_hits: function output is incorrect when the `attacker` cannot do any damage to the `defender`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `attacker` cannot do any damage to the `defender` (-2)'.The public tests cannot determine if your code satisfies these requirements. "
                                                          'Verify your code manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
