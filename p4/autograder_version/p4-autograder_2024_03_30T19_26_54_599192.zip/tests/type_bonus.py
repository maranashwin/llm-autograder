OK_FORMAT = True

test = {   'name': 'type_bonus',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> public_tests.rubric_check('type_bonus: function output is incorrect when the `defender` has only one type')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `defender` has only one type (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('type_bonus: function output is incorrect when the `defender` has two types')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `defender` has two types (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
