OK_FORMAT = True

test = {   'name': 'effective_damage',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> public_tests.rubric_check('effective_damage: `get_num_types` function is not used by `effective_damage`')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`get_num_types` function is not "
                                                          "used by `effective_damage` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('effective_damage: function output is incorrect when the `attacker` has only one type')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `attacker` has only one type (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('effective_damage: function output is incorrect when the `attacker` has two types')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `attacker` has two types (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
