OK_FORMAT = True

test = {   'name': 'q7',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q7', eff_damage_tyranitar_charizard)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q7: correct arguments are not passed to `effective_damage` function')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'correct arguments are not passed to "
                                                          "`effective_damage` function (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q7: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
