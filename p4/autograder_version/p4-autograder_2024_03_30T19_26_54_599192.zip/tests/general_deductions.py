OK_FORMAT = True

test = {   'name': 'general_deductions',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> public_tests.rubric_check(\'general_deductions: Did not save the notebook file prior to running the cell containing "export". We cannot see your '
                                               "output if you do not save before generating the zip file. This deduction will become stricter for future projects.')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Did not save the notebook file "
                                                          'prior to running the cell containing "export". We cannot see your output if you do not save before generating the zip file. This deduction '
                                                          "will become stricter for future projects. (-3)'.The public tests cannot determine if your code satisfies these requirements. Verify your "
                                                          'code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('general_deductions: Functions are defined more than once.')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Functions are defined more than "
                                                          "once. (-3)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('general_deductions: Import statements are not all placed at the top of the notebook.')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Import statements are not all "
                                                          "placed at the top of the notebook. (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('general_deductions: Used loops or other material not covered in class yet.')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Used loops or other material not "
                                                          "covered in class yet. (-20)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
