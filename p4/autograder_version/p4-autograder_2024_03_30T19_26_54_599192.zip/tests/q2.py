OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q2', damage_lucario_klawf)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q2: correct arguments are not passed to `damage` function')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'correct arguments are not passed to "
                                                          "`damage` function (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q2: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
