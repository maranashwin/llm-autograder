OK_FORMAT = True

test = {   'name': 'q19',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q19', friendship_ceruledge_skeledirge)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q19: correct arguments are not passed to `friendship_score` function')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'correct arguments are not passed to "
                                                          "`friendship_score` function (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q19: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
