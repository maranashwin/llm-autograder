OK_FORMAT = True

test = {   'name': 'damage',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('damage: function output is incorrect when the `attacker` needs to choose its physical attack')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `attacker` needs to choose its physical attack (-2)'.The public tests cannot determine if your code satisfies these requirements. "
                                                          'Verify your code manually.'},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('damage: function output is incorrect when the `attacker` needs to choose its special attack')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function output is incorrect when "
                                                          "the `attacker` needs to choose its special attack (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify "
                                                          'your code manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
