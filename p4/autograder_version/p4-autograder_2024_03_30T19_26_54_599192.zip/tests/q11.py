OK_FORMAT = True

test = {   'name': 'q11',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q11', battle_infernape_typhlosion)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q11: correct arguments are not passed to `battle` function')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'correct arguments are not passed to "
                                                          "`battle` function (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q11: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
