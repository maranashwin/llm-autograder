OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q3', highest_wage_nationality)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q3: incorrect logic is used to find the player with the highest `Wage`')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to find the "
                                                          "player with the highest `Wage` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('q3: incorrect logic is used to find the `Nationality` of the player with the highest `Wage`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to find the "
                                                          "`Nationality` of the player with the highest `Wage` (-1)'.The public tests cannot determine if your code satisfies these requirements. "
                                                          'Verify your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q3: `players` data structure is not used to read data')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`players` data structure is not "
                                                          "used to read data (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q3: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
