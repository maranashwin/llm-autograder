OK_FORMAT = True

test = {   'name': 'q5',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q5', premier_league_teams)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q5: incorrect logic is used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to answer "
                                                          "(-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q5: teams whose `League` is not exactly as required are added to the list')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'teams whose `League` is not exactly "
                                                          "as required are added to the list (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q5: `players` data structure is not used to read data')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`players` data structure is not "
                                                          "used to read data (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
