OK_FORMAT = True

test = {   'name': 'q11',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q11', positions_avg_attacking)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q11: `average_stat_by_position` function is not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`average_stat_by_position` function "
                                                          "is not used to answer (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
