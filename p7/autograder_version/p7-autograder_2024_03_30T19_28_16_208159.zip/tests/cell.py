OK_FORMAT = True

test = {   'name': 'cell',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> public_tests.rubric_check('cell: variables `csv_data`, `csv_header`, and `csv_rows` are not defined as expected')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'variables `csv_data`, `csv_header`, "
                                                          "and `csv_rows` are not defined as expected (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your "
                                                          'code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('cell: function does not typecast the correct columns to `int` or `float` as expected')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function does not typecast the "
                                                          "correct columns to `int` or `float` as expected (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify "
                                                          'your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('cell: function does not format the `Height` column correctly')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function does not format the "
                                                          "`Height` column correctly (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('cell: function does not use `format_euros` to format the relevant columns')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function does not use "
                                                          "`format_euros` to format the relevant columns (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify "
                                                          'your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('cell: function typecasts based on the column index and not the `col_name`')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function typecasts based on the "
                                                          "column index and not the `col_name` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
