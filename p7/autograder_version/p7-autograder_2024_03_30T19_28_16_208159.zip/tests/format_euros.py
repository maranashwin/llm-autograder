OK_FORMAT = True

test = {   'name': 'format_euros',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n>>> public_tests.rubric_check(\'format_euros: function logic is incorrect when the input ends with `"K"`\')\nAll test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect when "
                                                          'the input ends with `"K"` (-1)\'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually.'},
                                   {   'code': '>>> \n>>> public_tests.rubric_check(\'format_euros: function logic is incorrect when the input ends with `"M"`\')\nAll test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect when "
                                                          'the input ends with `"M"` (-1)\'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually.'},
                                   {   'code': '>>> \n'
                                               '>>> public_tests.rubric_check(\'format_euros: function logic is incorrect when the input does not end with `"K"` or `"M"`\')\n'
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect when "
                                                          'the input does not end with `"K"` or `"M"` (-1)\'.The public tests cannot determine if your code satisfies these requirements. Verify your '
                                                          'code manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
