OK_FORMAT = True

test = {   'name': 'average_stat_by_position',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> public_tests.rubric_check('average_stat_by_position: function logic is incorrect')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('average_stat_by_position: function only works for certain numerical columns')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function only works for certain "
                                                          "numerical columns (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('average_stat_by_position: `players` data structure is not used to read data')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`players` data structure is not "
                                                          "used to read data (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
