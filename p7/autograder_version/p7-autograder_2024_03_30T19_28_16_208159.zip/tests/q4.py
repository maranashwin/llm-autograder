OK_FORMAT = True

test = {   'name': 'q4',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q4', highest_wage_position)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q4: the player with the highest `Wage` is recomputed')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'the player with the highest `Wage` "
                                                          "is recomputed (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('q4: incorrect logic is used to find the `Position` of the player with the highest `Wage`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to find the "
                                                          "`Position` of the player with the highest `Wage` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify "
                                                          'your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q4: `players` data structure is not used to read data')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`players` data structure is not "
                                                          "used to read data (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
