OK_FORMAT = True

test = {   'name': 'q19',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q19', avg_attacking_prem_league)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q19: incorrect logic is used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to answer "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q19: best starting players of a single team is computed more than once')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'best starting players of a single "
                                                          "team is computed more than once (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q19: the list of unique teams in the league is recomputed')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'the list of unique teams in the "
                                                          "league is recomputed (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q19: `best_starting_players_of` function is not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`best_starting_players_of` function "
                                                          "is not used to answer (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q19: `players` data structure is not used to read data')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`players` data structure is not "
                                                          "used to read data (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
