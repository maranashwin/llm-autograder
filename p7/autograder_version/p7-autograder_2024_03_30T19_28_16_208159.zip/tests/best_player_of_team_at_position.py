OK_FORMAT = True

test = {   'name': 'best_player_of_team_at_position',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('best_player_of_team_at_position: function logic is incorrect when there is a unique best player of the `team` at "
                                               "`position`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect when "
                                                          "there is a unique best player of the `team` at `position` (-2)'.The public tests cannot determine if your code satisfies these "
                                                          'requirements. Verify your code manually.'},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('best_player_of_team_at_position: function logic is incorrect when there are multiple players tied for best player of "
                                               "the `team` at `position`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect when "
                                                          "there are multiple players tied for best player of the `team` at `position` (-1)'.The public tests cannot determine if your code satisfies "
                                                          'these requirements. Verify your code manually.'},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('best_player_of_team_at_position: function logic is incorrect when there are no players of the `team` at `position`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect when "
                                                          "there are no players of the `team` at `position` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify "
                                                          'your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('best_player_of_team_at_position: `players` data structure is not used to read data')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`players` data structure is not "
                                                          "used to read data (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
