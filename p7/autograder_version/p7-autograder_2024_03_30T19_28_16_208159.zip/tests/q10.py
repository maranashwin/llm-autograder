OK_FORMAT = True

test = {   'name': 'q10',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q10', positions_avg_height)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q10: incorrect logic is used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to answer "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q10: the keys of `positions_avg_height` are hardcoded')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'the keys of `positions_avg_height` "
                                                          "are hardcoded (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q10: `players` data structure is not used to read data')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`players` data structure is not "
                                                          "used to read data (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q10: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
