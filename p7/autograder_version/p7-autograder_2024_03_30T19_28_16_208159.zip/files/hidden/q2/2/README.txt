incorrect logic is used to find the statistics of the player with the highest `Value`

Check your code to ensure that it correctly
identifies the player with the highest 'Value' and
that you are extracting all their statistics
correctly. The test uses a modified dataset, so
make sure you're not relying on implicit dataset
patterns, but instead using logical comparisons to
find the correct result.