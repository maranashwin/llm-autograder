incorrect logic is used to find the player with the highest `Value`

Ensure your logic correctly identifies the player
with the highest `Value`. Verify that you loop
through all players, compare their `Value`
correctly, and update the highest valued player
accordingly. Consider boundary conditions and
initialization of variables. Review your
comparison and assignment statements.