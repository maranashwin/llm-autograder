teams whose `League` is not exactly as required are added to the list

Ensure your code matches the league exactly,
considers duplicates, and is case-sensitive. The
list should only include unique team names. Check
string comparison and the `set` function for
uniqueness.