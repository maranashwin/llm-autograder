incorrect logic is used to answer

Ensure your code appends teams to the list only if
they belong to 'Premier League (England)'. Convert
the list to a set to remove duplicates, then
convert it back to a list. Review dataset
modifications to account for any test failures.