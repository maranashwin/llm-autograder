`best_starting_players_of` function is not used to answer

The test checks if you used the
`best_starting_players_of` function as required.
Ensure you are calling this function with 'Paris
Saint Germain' as an argument and returning the
result without additional processing. Modify your
code to use the function and retest.