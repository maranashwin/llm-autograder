incorrect logic is used to answer

The test checks correct usage of comparison logic
to find the position with the highest average
'Defending' stat. Review your use of the
`average_stat_by_position` function and ensure you
are comparing average stat values correctly to
identify the highest one.