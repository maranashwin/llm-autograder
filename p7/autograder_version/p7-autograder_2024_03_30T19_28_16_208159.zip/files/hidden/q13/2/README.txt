`average_stat_by_position` function is not used to answer

The test checks if you used
`average_stat_by_position` function to calculate
average attacking stats by position. Ensure your
code calls this function with 'Attacking' as an
argument and assigns the result to
`positions_avg_attacking`. Review the usage of
this function and update your code accordingly.