function logic is incorrect when there are no players of the `team` at `position`

Check whether your function properly handles cases
where there are no players at the given position
for the given team, as it should return `None`.
Ensure the function iterates through all players
and that conditions for `position` and `team`
match correctly.