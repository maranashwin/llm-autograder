function logic is incorrect when there are multiple players tied for best player of the `team` at `position`

Check whether your function correctly handles ties
by choosing the player with the smaller ID. Review
your comparisons to ensure ties are broken by ID
and that None is returned if there are no players
at a position for a team.