function logic is incorrect when there is a unique best player of the `team` at `position`

Check the conditions and comparisons in your
function to ensure that you are identifying the
unique best player correctly. Make sure to test
your function with scenarios where one player has
a higher 'Overall rating' at a given 'position'
for a 'team'. Also, check how you handle
comparisons and the return value for the best
player's 'ID'.