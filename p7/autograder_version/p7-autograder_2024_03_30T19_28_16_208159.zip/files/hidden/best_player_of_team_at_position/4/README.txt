`players` data structure is not used to read data

The test checks if the 'players' data structure is
correctly utilized to fetch statistics. To pass,
ensure you reference the 'players' dictionary with
the player ID as the key to get all column values.
Revisit your code and verify you're using
'players' as specified.