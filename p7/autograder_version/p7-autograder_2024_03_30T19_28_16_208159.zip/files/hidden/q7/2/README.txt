the keys of `preferred_foot_avg_overall` are hardcoded

The test checks for hardcoded keys in your
`preferred_foot_avg_overall` dictionary. Ensure
you are not directly specifying the foot names in
the dictionary. Instead, extract these dynamically
from your data. Re-examine your code to ensure the
foot names are derived from the `players`
dictionary keys or values.