the keys of `positions_count` are hardcoded

Ensure you are dynamically extracting position
names from the dataset, not hardcoding them. Check
your loop and dictionary key assignment logic,
referring to the solution's method for updating
the count for each position. Update your code to
respond to varying datasets.