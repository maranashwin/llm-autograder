data structure is not defined correctly

Check your implementation of the `players`
dictionary ensures each inner dictionary properly
maps column names to their values. Ensure data
types for each value correspond to the example
given, such as integer for 'Age', 'Value', 'Wage',
and 'Overall rating'. Make sure to use the given
`cell` function correctly to retrieve cell data.