logic used to define data structure is incorrect

Ensure your logic for creating the dictionary of
dictionaries matches the provided solution. Check
for correct looping through rows and columns, and
that each player's ID maps to their respective
data. Verify that column names correctly match
their values.