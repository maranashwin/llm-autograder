incorrect logic is used to find the player with the highest `Wage`

Ensure that your logic correctly identifies the
unique player with the highest wage by comparing
each player's wage. Review your loop and
comparison conditions for potential errors.