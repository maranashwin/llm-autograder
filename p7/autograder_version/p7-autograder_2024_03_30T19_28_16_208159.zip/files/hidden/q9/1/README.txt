incorrect logic is used to answer

Test conducted on an altered dataset to examine
the logic used for calculating averages. Review
the division of total age by count for each
position. Ensure you're accounting for all players
and not using hardcoded values.