the keys of `positions_avg_age` are hardcoded

The test validates that `positions_avg_age` keys
are dynamically populated from the data. Verify
your code iterates through the `players`
dictionary and extracts position information
directly from it, ensuring it creates keys based
on the actual positions found, rather than using
hardcoded values.