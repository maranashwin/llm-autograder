`best_player_of_team_at_position` function is not used to answer

Check that your `best_starting_players_of`
function utilizes the
`best_player_of_team_at_position` function
appropriately for each position. Ensure the
function handles ties by ID and excludes positions
with no players. Review your logic for correctness
and adherence to the question's requirements.