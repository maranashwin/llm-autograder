function logic is incorrect

The function should correctly map the best player
at each position for a given team, considering
overall ratings and ID values for tie-breaking.
Verify your logic for handling tiebreaks and
ensure positions with no players are not included
in the output. Update your code to address these
requirements and pass all unique team inputs.