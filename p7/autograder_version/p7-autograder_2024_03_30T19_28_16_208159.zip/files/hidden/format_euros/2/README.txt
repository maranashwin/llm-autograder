function logic is incorrect when the input ends with `"M"`

Check your handling of inputs ending with "M". It
should correctly convert millions and round to the
nearest integer. Review conditions and
mathematical operations for accuracy.