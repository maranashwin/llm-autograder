function logic is incorrect when the input ends with `"K"`

Check the implementation of `format_euros` for
converting inputs ending with 'K'. Ensure it
correctly interprets 'K' as thousands and rounds
the final integer appropriately.