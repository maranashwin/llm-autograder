the player with the highest `Wage` is recomputed

Ensure you're using the `ID` from Question 3 to
find the `Position` of the player with the highest
`Wage`. Check if you've stored the `ID` correctly
and are not computing the player with the highest
`Wage` again. Review how to access the `Position`
using the stored `ID`.