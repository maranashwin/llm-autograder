incorrect logic is used to find the `Position` of the player with the highest `Wage`

Check that the logic in your code uses the `ID`
from Question 3 to find the `Position` of the
player with the highest `Wage`. Avoid re-computing
or using any other attributes to identify the
player. Make sure the `ID` is correctly stored and
used in Question 4.