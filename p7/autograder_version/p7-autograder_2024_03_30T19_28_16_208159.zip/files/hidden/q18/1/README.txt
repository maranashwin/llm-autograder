incorrect logic is used to answer

Ensure your logic correctly differentiates between
the best starting players and the bench players
for the team 'FC Barcelona'. Calculate the
cumulative value by summing the 'Value' of only
the bench players, excluding the starting ones.
Review the use of relevant functions and
conditions in your code.