`best_starting_players_of` function is not used to find the best starting players

Check if you're correctly using the
`best_starting_players_of` function to identify
the best starting players for FC Barcelona and
then summing the value of all other players not in
that list. Review your usage of this function and
ensure you're considering all non-starter players
when calculating the cumulative value.