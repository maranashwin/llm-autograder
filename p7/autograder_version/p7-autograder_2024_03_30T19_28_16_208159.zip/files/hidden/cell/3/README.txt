function does not format the `Height` column correctly

Check that your `cell` function correctly slices
off the unit from the `Height` value and converts
it to an integer. Revisit string slicing and typecasting
to integer in Python.