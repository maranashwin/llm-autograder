variables `csv_data`, `csv_header`, and `csv_rows` are not defined as expected

Ensure `csv_data`, `csv_header`, and `csv_rows`
are correctly defined and populated from
`soccer_stars.csv`. Verify that `process_csv` is
defined and called with the correct filename, and
`csv_data` is correctly split into `csv_header`
and `csv_rows`.