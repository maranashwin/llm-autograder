function does not typecast the correct columns to `int` or `float` as expected

Ensure that your `cell` function correctly
typecasts column values to the specified data
types. Review the list of columns and their target
data types, and compare these to your typecasting
logic. Consider using type conversion functions
like `int()` for integers and `float()` for
floating-point numbers where appropriate.