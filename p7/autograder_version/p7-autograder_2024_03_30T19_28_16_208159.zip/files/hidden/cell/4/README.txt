function does not use `format_euros` to format the relevant columns

Ensure your `cell` function converts 'Value' and
'Wage' to integers using `format_euros` helper
function. Test your function for different row
indices and especially on 'Value' and 'Wage'
columns to confirm the conversion.