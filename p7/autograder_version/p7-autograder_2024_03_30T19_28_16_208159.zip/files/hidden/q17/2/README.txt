`best_starting_players_of` function is not used to answer

The test checks if the `best_starting_players_of`
function is used appropriately. Review the usage
of this function in your code and ensure it is
implemented correctly to build the final
dictionary. Consider different scenarios on how
the function's output can affect your result.