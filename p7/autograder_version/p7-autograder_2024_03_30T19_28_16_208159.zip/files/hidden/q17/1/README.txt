incorrect logic is used to answer

The test checks for correct logic in obtaining the
best starting players. Please review your
implementation for logical errors and ensure you
are using the `best_starting_players_of` function
correctly. Verify that your code successfully
handles different datasets.