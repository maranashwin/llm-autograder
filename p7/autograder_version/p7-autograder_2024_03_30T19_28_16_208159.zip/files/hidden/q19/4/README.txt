`best_starting_players_of` function is not used to answer

Check if you are using the
`best_starting_players_of` function to get the
best starters. Ensure you are iterating correctly
over teams and calculating the average by summing
the `Attacking` stats and dividing by the number
of best starting players. Reuse lists and
functions wherever possible to avoid redundancy
and extra computations.