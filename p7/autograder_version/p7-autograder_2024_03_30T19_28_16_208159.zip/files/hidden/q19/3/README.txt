the list of unique teams in the league is recomputed

Ensure you are using the correct list of Premier
League teams. If you recompute or redefine the
list, verify it contains the appropriate teams.
Use the earlier computed list if available, and
calculate the average as instructed.