incorrect logic is used to answer

Examine your code to ensure that the logic you've
implemented for calculating the average attacking
stat is correct and adheres to the question's
requirements. Review the use of loops,
accumulation of the sum of attacking stats, and
the division by the number of best starting
players, comparing it to the provided solution.