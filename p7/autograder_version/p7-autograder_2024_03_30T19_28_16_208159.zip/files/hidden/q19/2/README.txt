best starting players of a single team is computed more than once

Make sure to reuse the result from calling
`best_starting_players_of` for each team instead
of calling the function multiple times for the
same team. Store its output in a variable and use
that to calculate the average. This can improve
performance and avoid possible repetition in
computation.