incorrect logic is used to answer

Check your logic for finding the highest average
'Attacking' stat. Ensure you're using the
precomputed average for each team and not
recalculating it. Consider edge cases and verify
you're comparing the correct values.