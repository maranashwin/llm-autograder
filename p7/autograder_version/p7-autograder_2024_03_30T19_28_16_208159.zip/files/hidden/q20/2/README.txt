`avg_attacking_prem_league` is not used to answer

Ensure the existing `avg_attacking_prem_league`
dictionary is utilized to determine the team with
the highest average attacking stat. Looping
through the dataset again or recomputation should
be avoided. Check if the dictionary is correctly
referenced and used in your solution.