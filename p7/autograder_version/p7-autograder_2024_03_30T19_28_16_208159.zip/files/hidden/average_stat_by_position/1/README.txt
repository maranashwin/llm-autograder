function logic is incorrect

Check if the function correctly calculates
averages by initializing and updating counters and
sums for each position. Ensure correct dictionary
construction, use of keys for indexing, and
division to calculate averages. Review the
handling of different column names and
corresponding data types.