function only works for certain numerical columns

Check that calculations of averages handle various
numerical data types and ensure that your function
iterates over all players and positions. Verify
that the function doesn't have hardcoded column
names or conditions that limit it to specific
columns.