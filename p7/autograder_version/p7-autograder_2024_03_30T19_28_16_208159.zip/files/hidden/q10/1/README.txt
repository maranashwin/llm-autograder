incorrect logic is used to answer

Ensure you cycle through all player entries to sum
heights and count occurrences by position, then
calculate the average height for each position.
Avoid hardcoding. Check and debug your loop and
dictionary operations for correct logic.