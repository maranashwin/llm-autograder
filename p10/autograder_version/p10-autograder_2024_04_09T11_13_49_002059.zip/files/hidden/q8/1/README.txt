incorrect logic is used to answer

The dataset is modified in a way that some stars
have missing `stellar_age` data, some have 0 as
their `stellar_age` value, and some have very high
`stellar_age` values. Your code needs to correctly
skip stars with missing `stellar_age` data and
calculate the average `stellar_age` of the
remaining stars.