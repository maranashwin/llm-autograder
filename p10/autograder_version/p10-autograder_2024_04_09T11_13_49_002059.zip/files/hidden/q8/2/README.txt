`get_stars` function is not used to answer

This test is checking if you are using the
`get_stars` function to answer the question. A
modification has been made to the `get_stars`
function so that it reads from a different
file. If your answer does not change
accordingly, it suggests that you did not use the
`get_stars` function. Remember to utilize the
provided functions instead of reading the data
directly from the csv again.