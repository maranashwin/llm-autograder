`stars_1_dict` data structure is not used to answer

You need to access the `Star` object for the star
named DP Leo in the `stars_1_dict` dictionary. The
dictionary already contains all the data about the
stars in `stars_1.csv`. Make sure to use the data
from the `stars_1_dict` dictionary to answer the
question. A modified version of the dictionary is
provided right before the answer to this question.
If your answer does not use this modified data
structure, you may not have used the data
correctly.