`planet_cell` function is not used

This test is checking if you are using the
`planet_cell` function to define this function. A
modification has been made to the `planet_cell`
function so that it reads from a different
dataset. If the output of this function does not change
accordingly, it suggests that you did not use the
`planet_cell` function. Remember to utilize the
provided functions instead of reading the data
directly from the csv again.