data structure is defined incorrectly

This test is attempting to
ensure that you have defined your Planet namedtuple
correctly. It tries to create a new Planet object
using your definition. The successful creation of
this object would confirm that the planet object
meets the necessary structure that will be used in
the later parts of the project.