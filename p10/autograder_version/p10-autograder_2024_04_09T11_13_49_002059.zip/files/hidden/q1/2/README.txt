answer does not remove all files and directories that start with `.`

This test verifies your ability to correctly list
the names of files in the directory, excluding
those that system typically generates and start
with a ".". The dataset is modified for this test.
Some files beginning with a "." have been added to
verify if your code can correctly ignore
system-specific files while listing the actual
dataset files.