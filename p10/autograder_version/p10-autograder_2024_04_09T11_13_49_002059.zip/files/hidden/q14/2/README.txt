`get_planets` function is not used to answer

This test is checking if you are using the
`get_planets` function to answer the question. A
modification has been made to the `get_planets`
function so that it reads from different
files. If your answer does not change
accordingly, it suggests that you did not use the
`get_planets` function. Remember to utilize the
provided functions instead of reading the data
directly from the csv and json files again.