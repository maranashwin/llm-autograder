incorrect logic is used to answer

The code is attempting to find the Planet objects
whose controversial_flag attribute is True in a
given list. To test if your code is correctly
identifying these planets, we have modified the
dataset completely. Make sure your code is not
just relying on specific values in the original
dataset, but instead is correctly identifying
planets with the controversial_flag set to True in
any dataset.