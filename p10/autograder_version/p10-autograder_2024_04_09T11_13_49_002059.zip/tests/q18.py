OK_FORMAT = True

test = {   'name': 'q18',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q18', toi_2022_c_star)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q18: `planets_list` and `stars_dict` data structures are not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`planets_list` and `stars_dict` "
                                                          "data structures are not used to answer (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q18: did not exit loop and instead iterated further after finding the answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'did not exit loop and instead "
                                                          "iterated further after finding the answer (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your "
                                                          'code manually.'},
                                   {'code': ">>> public_tests.rubric_check('q18: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
