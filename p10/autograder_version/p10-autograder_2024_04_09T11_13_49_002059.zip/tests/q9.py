OK_FORMAT = True

test = {   'name': 'q9',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q9', kepler_220_temp)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q9: `stars_dict` data structure is not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`stars_dict` data structure is not "
                                                          "used to answer (-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
