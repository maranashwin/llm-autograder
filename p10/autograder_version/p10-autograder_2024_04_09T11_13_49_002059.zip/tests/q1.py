OK_FORMAT = True

test = {   'name': 'q1',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q1', files_in_data)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q1: answer is not sorted explicitly')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'answer is not sorted explicitly "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q1: answer does not remove all files and directories that start with `.`')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'answer does not remove all files "
                                                          "and directories that start with `.` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
