OK_FORMAT = True

test = {   'name': 'stars_dict',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> public_tests.rubric_check('stars_dict: data structure is defined incorrectly')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'data structure is defined "
                                                          "incorrectly (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('stars_dict: `get_stars` function is not used')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`get_stars` function is not used "
                                                          "(-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('stars_dict: `stars_paths` is not used to find paths of necessary files')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`stars_paths` is not used to find "
                                                          "paths of necessary files (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
