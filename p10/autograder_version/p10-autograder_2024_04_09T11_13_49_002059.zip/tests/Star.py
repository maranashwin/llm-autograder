OK_FORMAT = True

test = {   'name': 'Star',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('Star', sun)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('Star: data structure is defined more than once')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'data structure is defined more than "
                                                          "once (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('Star: data structure is defined incorrectly')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'data structure is defined "
                                                          "incorrectly (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
