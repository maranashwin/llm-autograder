OK_FORMAT = True

test = {   'name': 'q17',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q17', planets_disc_2023)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q17: incorrect comparison operator is used')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect comparison operator is "
                                                          "used (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q17: incorrect logic is used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to answer "
                                                          "(-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q17: `planets_list` data structure is not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`planets_list` data structure is "
                                                          "not used to answer (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
