OK_FORMAT = True

test = {   'name': 'get_planets',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> public_tests.rubric_check('get_planets: function logic is incorrect')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('get_planets: hardcoded the name of directory inside the function instead of passing it as a part of the input "
                                               "argument')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'hardcoded the name of directory "
                                                          "inside the function instead of passing it as a part of the input argument (-1)'.The public tests cannot determine if your code satisfies "
                                                          'these requirements. Verify your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('get_planets: function is called more than twice with the same dataset')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function is called more than twice "
                                                          "with the same dataset (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('get_planets: `planet_cell` function is not used')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`planet_cell` function is not used "
                                                          "(-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('get_planets: function is defined more than once')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function is defined more than once "
                                                          "(-3)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
