OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q2', file_paths)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q2: recomputed variable defined in Question 1, or the answer is not sorted explicitly')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'recomputed variable defined in "
                                                          "Question 1, or the answer is not sorted explicitly (-1)'.The public tests cannot determine if your code satisfies these requirements. "
                                                          'Verify your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q2: answer does not remove all files and directories that start with `.`')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'answer does not remove all files "
                                                          "and directories that start with `.` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q2: paths are hardcoded using slashes')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'paths are hardcoded using slashes "
                                                          "(-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
