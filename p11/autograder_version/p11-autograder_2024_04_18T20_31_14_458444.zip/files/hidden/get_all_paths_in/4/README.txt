function logic is incorrect

Ensure your recursive logic correctly explores all
subdirectories and performs the appropriate checks
for file names starting with '.'. Verify that all
paths are relative and that the final list is
sorted in reverse alphabetical order. Use the `os`
module functions appropriately. Consider edge
cases and test with different directory
structures.