function does not remove all files and directories that start with `.`

Check that your function correctly ignores files
and directories beginning with a dot (`.`). Review
how you filter such items and ensure they are
excluded from the results before sorting. Apply
recursion properly to handle nested directories.