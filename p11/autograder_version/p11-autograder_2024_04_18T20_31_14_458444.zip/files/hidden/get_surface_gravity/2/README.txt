function logic is incorrect

Check for proper calculation of gravity ratio
considering that Earth's gravity is a constant
factor. Review the use of physical constants and
ensure that any conditional checks for `None` are
correctly implemented. Consider edge cases and
retest your function with various inputs.