function did not return `None` for missing data

Check if your function `get_surface_gravity`
returns `None` when either `planet_mass` or
`planet_radius` attribute of the `Planet` object
is `None`. Ensure that missing data is handled
correctly.