OK_FORMAT = True

test = {   'name': 'q20',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q20', habitable_planets)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q20: incorrect logic is used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to answer "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('q20: `get_surface_gravity`, `get_distances_to_star`, `get_liquid_water_distances`, and `get_surface_temperatures` "
                                               "functions are not used to answer')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`get_surface_gravity`, "
                                                          "`get_distances_to_star`, `get_liquid_water_distances`, and `get_surface_temperatures` functions are not used to answer (-1)'.The public "
                                                          'tests cannot determine if your code satisfies these requirements. Verify your code manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q20: `all_planets_list` data structure is not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`all_planets_list` data structure "
                                                          "is not used to answer (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q20: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
