OK_FORMAT = True

test = {   'name': 'general_deductions',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> public_tests.rubric_check(\'general_deductions: Outputs not visible/did not save the notebook file prior to running the cell containing "export". '
                                               "We cannot see your output if you do not save before generating the zip file.')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Outputs not visible/did not save "
                                                          'the notebook file prior to running the cell containing "export". We cannot see your output if you do not save before generating the zip '
                                                          "file. (-3)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('general_deductions: Used concepts/modules such as csv.DictReader, os.walk, and pandas not covered in class yet. Note "
                                               "that built-in functions that you have been introduced to can be used.')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Used concepts/modules such as "
                                                          'csv.DictReader, os.walk, and pandas not covered in class yet. Note that built-in functions that you have been introduced to can be used. '
                                                          "(-3)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('general_deductions: Large outputs such as stars_dict or planets_list are displayed in the notebook.')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Large outputs such as stars_dict or "
                                                          "planets_list are displayed in the notebook. (-3)'.The public tests cannot determine if your code satisfies these requirements. Verify your "
                                                          'code manually.'},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('general_deductions: Import statements are not mentioned in the required cell at the top of the notebook.')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'Import statements are not mentioned "
                                                          "in the required cell at the top of the notebook. (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify "
                                                          'your code manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
