OK_FORMAT = True

test = {   'name': 'get_all_paths_in',
    'points': 0,
    'suites': [   {   'cases': [   {   'code': ">>> \n>>> public_tests.rubric_check('get_all_paths_in: hardcoding the name of directory inside the function')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'hardcoding the name of directory "
                                                          "inside the function (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': '>>> \n'
                                               ">>> public_tests.rubric_check('get_all_paths_in: function does not remove all files and directories that start with `.`')\n"
                                               'All test cases passed!\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function does not remove all files "
                                                          "and directories that start with `.` (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code "
                                                          'manually.'},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('get_all_paths_in: function does not sort file names explicitly')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function does not sort file names "
                                                          "explicitly (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('get_all_paths_in: function logic is incorrect')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'function logic is incorrect "
                                                          "(-2)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('get_all_paths_in: paths are hardcoded using slashes')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'paths are hardcoded using slashes "
                                                          "(-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
