OK_FORMAT = True

test = {   'name': 'q15',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q15', distances_to_star_b_cen_ab_b)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q15: `get_distances_to_star` function is not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`get_distances_to_star` function is "
                                                          "not used to answer (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q15: `all_planets_list` data structure is not used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - '`all_planets_list` data structure "
                                                          "is not used to answer (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q15: did not exit loop and instead iterated further after finding the answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'did not exit loop and instead "
                                                          "iterated further after finding the answer (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your "
                                                          'code manually.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
