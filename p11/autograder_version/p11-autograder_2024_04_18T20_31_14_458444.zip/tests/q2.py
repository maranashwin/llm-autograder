OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0,
    'suites': [   {   'cases': [   {'code': ">>> public_tests.check('q2', coeff_gj9827)\nAll test cases passed!\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q2: incorrect logic is used to answer')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'incorrect logic is used to answer "
                                                          "(-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {   'code': ">>> \n>>> public_tests.rubric_check('q2: recomputed variable defined in Question 1')\nAll test cases passed!\n",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': "Note that the Gradescope autograder will deduct points if your code fails the following rubric point - 'recomputed variable defined in "
                                                          "Question 1 (-1)'.The public tests cannot determine if your code satisfies these requirements. Verify your code manually."},
                                   {'code': ">>> public_tests.rubric_check('q2: public tests')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
