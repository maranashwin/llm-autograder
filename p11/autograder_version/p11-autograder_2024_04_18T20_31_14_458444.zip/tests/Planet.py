OK_FORMAT = True

test = {   'name': 'Planet',
    'points': 0,
    'suites': [   {   'cases': [{'code': ">>> print('All test cases passed!')\nAll test cases passed!\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
