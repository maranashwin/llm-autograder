OK_FORMAT = True

test = {   'name': 'summary',
    'points': 127,
    'suites': [   {   'cases': [   {'code': '>>> \n>>> public_tests.detect_public_tests()\n', 'hidden': True, 'locked': False, 'points': 0},
                                   {'code': '>>> \n>>> public_tests.get_score_digit(6) == 1\nTrue', 'hidden': True, 'locked': False, 'points': 64},
                                   {'code': '>>> \n>>> public_tests.get_score_digit(5) == 1\nTrue', 'hidden': True, 'locked': False, 'points': 32},
                                   {'code': '>>> \n>>> public_tests.get_score_digit(4) == 1\nTrue', 'hidden': True, 'locked': False, 'points': 16},
                                   {'code': '>>> \n>>> public_tests.get_score_digit(3) == 1\nTrue', 'hidden': True, 'locked': False, 'points': 8},
                                   {'code': '>>> \n>>> public_tests.get_score_digit(2) == 1\nTrue', 'hidden': True, 'locked': False, 'points': 4},
                                   {'code': '>>> \n>>> public_tests.get_score_digit(1) == 1\nTrue', 'hidden': True, 'locked': False, 'points': 2},
                                   {'code': '>>> \n>>> public_tests.get_score_digit(0) == 1\nTrue', 'hidden': True, 'locked': False, 'points': 1},
                                   {   'code': '>>> \n>>> public_tests.get_summary()\nTotal Score: 100/100\n',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': 'Please submit your zip folder to Gradescope, and check your final score there. The Gradescope autograder will make deductions to your score '
                                                          'based on the rubric.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
